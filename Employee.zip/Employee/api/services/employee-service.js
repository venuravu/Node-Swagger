'use strict';

const Bluebird = require('bluebird');
const moment = require('moment');
const dbAdapter = require('@npm-suresh/proj-db-adapter');
const config = {
    db :{
        dbServer : "MONGODB",
        host: "mongodb://localhost:27017/Employee",
        collection: "Employee"
    }
};

const createEmployee = (payload) => {
    const inputParam = Object.assign({},payload);

    return Bluebird.try(() => dbAdapter())
        .then((db) => db.collection.insertOneAsync(inputParam))
        .then((record) => {
        let output;
        if(!record) {
            console.log("record insertion failed");
        }else{
            const result = record.ops[0];
            output = {
                empid: result.empid
            };
        }
            return output;
        });
};

class EmployeeService {

    constructor(){
       new Bluebird((resolve, reject) => {
            const mongodb = dbAdapter(config.db);
            mongodb.on('connected', () => {});
            mongodb.on('error', (err) => reject(err))
        });
    }

    createUniqueEmployee(payload){
        const inputParams = Object.assign({},payload);
        return this.getEmployeeByEmpId(payload.empid)
            .then((record) => {
                if(!record){
                    return createEmployee(payload);
                }else{
                    console.log("record already exists");
                }
            }
        );
    }

    getEmployeeByEmpId(empId){
        const inputParams = {
            "empid":empId
        };
        return Bluebird.try(() => dbAdapter())
            .then((db) => db.collection.findOne(inputParams))
            .then((doc) => {
                let output;
                if(!doc){
                    console.log("no record found");
                }else{
                    output = {
                        empid: doc.empid,
                        empname: doc.empname,
                        sal: doc.sal
                    };
                }
                return output;
            });
    }

    getAllEmployees(){
        return Bluebird.try(() => dbAdapter())
            .then((db) =>  db.collection.find().toArray())
            .then(function (docs){
            /*let output = [];
                if(docs){
                    docs.forEach(function(empJson){
                        delete empJson._id;
                        output.push(empJson);
                    });
                }else{
                    console.log("No records found");
                }
            console.log(output);*/
            return docs;
            });
    }

    deleteEmployee(empId){
        const inputParams = {empid: empId};
        return Bluebird.try(() => dbAdapter())
            .then((db) => db.collection.remove(inputParams))
            .then(function (result){
                /*console.log(err);
                console.log(result);
                if(err){
                    console.log("unable to delete document");
                }else{
                    console.log("document deleted succesfully");
                }*/
                return result;
            });
    }
}

module.exports = new EmployeeService();


