'use strict';

const Bluebird = require('bluebird');
const EventEmitter = require('events').EventEmitter;
const dbAdapter = require('@npm-suresh/proj-db-adapter');
const config = require("config");

class ApplicationStarter extends EventEmitter{

    startApplication() {
        return new Bluebird((resolve, reject) => {
            const mongodb = dbAdapter(config.db);
            mongodb.on('connected', () => {
                console.log("Mongo Connected successfully");
            });
            mongodb.on('error', (err) => reject(err))
        });
    }
}

module.exports = new ApplicationStarter();