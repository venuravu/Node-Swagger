'use strict';

module.exports = {
    statusCodes: {
        ok: 200,
        created: 201,
        updated: 202,
        deleted: 203,
        badRequest: 400,
        unauthorized: 403,
        notfound: 404,
        serverError: 500
    }
}
