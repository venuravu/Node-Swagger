'use strict';

const constants = require("../helpers/constants");
const EmployeeService = require('../services/employee-service');


const getEmployees = ({}, res, next) => {
   EmployeeService.getAllEmployees()
        .then((records) => {
            let output = [];
            if(!records) {
                res.header('Content-Type', 'application/json')
                    .status(constants.statusCodes.notfound).send({message: "No records found"});
            }else{
                records.forEach(function(empJson){
                    delete empJson._id;
                    output.push(empJson);
                });
                res.status(constants.statusCodes.ok).send(records);
            }
        });

};

const saveEmployee = ({body}, res, next) =>{
    const inputParams = Object.assign({},body);

    EmployeeService.createUniqueEmployee(inputParams)
        .then((record) => {
            if (!record) {
                res.header('Content-Type', 'application/json')
                    .status(constants.statusCodes.notfound).send({message: "No such record found"});
            } else {
                res.status(constants.statusCodes.ok).send(record);
            }
        });
};

const getEmpById = (req, res, next) =>{
        const empid = req.swagger.params.empid.value;
        EmployeeService.getEmployeeByEmpId(empid)
            .then((record) => {
                console.log(record);
                if (!record) {
                    res.header('Content-Type', 'application/json')
                        .status(constants.statusCodes.notfound).send({message: "No such record found"});

                } else {
                    res.status(constants.statusCodes.ok).send(record);
                }
            }).catch(next);
};

const updateEmployee = ({body}, res, next) =>{



};

const deleteEmployee = (req, res, next) =>{
    EmployeeService.deleteEmployee(req.swagger.params.empid.value)
        .then((doc) => {
        console.log(doc.result.n);
        if(doc.result.n == 1){
            res.status(constants.statusCodes.ok).send({empid:req.swagger.params.empid.value});
        }else{
            res.header('Content-Type', 'application/json')
                .status(constants.statusCodes.notfound).send({message: "No such record to delete"});
        }
        });
}

module.exports = {
    getEmployees: getEmployees,
    saveEmployee: saveEmployee,
    updateEmployee: updateEmployee,
    deleteEmployee: deleteEmployee,
    getEmpById:getEmpById
};