module.exports = {
        db :{
            dbServer : "MONGODB",
            host: "mongodb://localhost:27017/Employee",
            collection: "Employee"
        }

};
